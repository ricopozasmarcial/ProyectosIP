

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LampTest.
 *
 * @author  MARCIAL RICO POZAS
 * @version 28/10/2017
 */
public class LampTest
{
    /**
     * Default constructor for test class LampTest
     */
    public LampTest()
    {
        
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        
      
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo test para turnOn
     */
    @Test
    public void testTurnOn()
    {
     //caso en el que la lampara esté encendida
     Lamp lamp1 = new Lamp();
     lamp1.turnOn();
     assertEquals(Lamp.LAMP_ON,lamp1.getState());
    }
    
    /**
     * metodo test para turnOff
     */
    @Test
    public void testTurnOff()
    {
     //caso en el que la lampara esté apagada
     Lamp lamp1 = new Lamp();
     lamp1.turnOff();
     assertEquals(Lamp.LAMP_OFF,lamp1.getState());
    }
    
    /**
     * metodo test para toString()
     */
    @Test
    public void testToString()
    {
     //si la lampara está encendida
     Lamp lamp1 = new Lamp();
     lamp1.turnOn();
     assertEquals(Lamp.LAMP_ON,lamp1.getState());
     assertEquals("ENCENDIDA",lamp1.toString());
     
     //si la lampara está apagada
     lamp1 = new Lamp();
     lamp1.turnOff();
     assertEquals(Lamp.LAMP_OFF,lamp1.getState());
     assertEquals("APAGADA",lamp1.toString());
    }
}
