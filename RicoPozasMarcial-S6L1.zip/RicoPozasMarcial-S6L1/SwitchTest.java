

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SwitchTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SwitchTest
{
    /**
     * Default constructor for test class SwitchTest
     */
    public SwitchTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo test para press()
     */
    @Test
    public void testPress()
    {
     //en caso de que el interruptor esté apagado
     Switch switch1 = new Switch(Switch.OFF);
     switch1.press();
     assertEquals(Switch.ON,switch1.getSwitchPosition());
     
     //en caso de que el interuptor esté encencido
     switch1 = new Switch(Switch.ON);
     switch1.press();
     assertEquals(Switch.OFF,switch1.getSwitchPosition());
    }
    
    /**
     * metodo test para toString()
     */
    @Test
    public void testToString()
    {
     //si el interruptor está apagado
     Switch switch1 = new Switch(Switch.OFF);
     assertEquals("OFF",switch1.toString());
     
     //si el interruptor está encendido
     switch1 = new Switch(Switch.ON);
     assertEquals("ON",switch1.toString());

    }
}
