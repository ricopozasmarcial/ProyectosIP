

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class ControlPanelTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ControlPanelTest
{
    /**
     * Default constructor for test class ControlPanelTest
     */
    public ControlPanelTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo test para press()
     */
    @Test
    public void testPress()
    {
     //el botón está apagado con lo cual la lámpara también
     ControlPanel controlp1 = new ControlPanel(new Lamp(), new Switch(), null, null);
     controlp1.press(); //pulsamos el boton, por tanto se enciende la lampara
     assertEquals(Switch.ON,controlp1.getSwitch1().getSwitchPosition());
     assertEquals(Lamp.LAMP_ON,controlp1.getLamp1().getState());
     
     //el boton está encendido con lo cual la lampara tambien
     controlp1.press(); 
     assertEquals(Switch.OFF,controlp1.getSwitch1().getSwitchPosition());
     assertEquals(Lamp.LAMP_OFF,controlp1.getLamp1().getState());
    }
    
    /**
     * metodo test para movePotentiometer()
     */
    @Test
    public void testMovePotentiometer()
    {
     //caso en el que la posicion y temperatura sean mínimas
     ControlPanel controlp1 = new ControlPanel();
     controlp1.movePotentiometer(0);
     assertEquals(10.0,controlp1.getHeater1().getTemperature(),0.1);
     assertEquals(0,controlp1.getPotentiometer1().getPosition());
     
     //caso en el que la posicion y la temperatura sean maximas
     controlp1.movePotentiometer(10);
     assertEquals(27.0,controlp1.getHeater1().getTemperature(),0.1);
     assertEquals(10,controlp1.getPotentiometer1().getPosition());
    }
}
