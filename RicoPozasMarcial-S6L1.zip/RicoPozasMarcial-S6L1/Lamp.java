
/**
 * Clase Lamp para el proyecto Sesión 6 de IP
 * 
 * @author MARCIAL RICO POZAS 
 * @version 28/10/2017
 */
public class Lamp
{
    //constantes de la clase Lamp
    public final static boolean LAMP_ON = true;
    public final static boolean LAMP_OFF = false;
    
    //atributos de la clase Lamp
    private boolean state;
    /**
     * Constructor de objetos de la clase Lamp (sin parámetros)
     */
    public Lamp()
    {
     setState(LAMP_OFF);
    }
    
    /**
     * constructor con parámetros de objetos de la clase Lamp
     */
    public Lamp (boolean state)
    {
     setState(state);
    }
    
    /**
     * método set de objetos de la clase Lamp
     * @param state, un booleano que establece el estado de la lámpara
     */
    private void setState(boolean state)
    {
     this.state = state;
    }
    
    /**
     * método get de objetos de la clase Lamp
     * @return el valor de state
     */
    public boolean getState()
    {
     return this.state;
    }
    
    /**
     * método turnOn para objetos de la clase Lamp
     */
    public void turnOn()
    {
     this.state = LAMP_ON;
    }
    
    /**
     * método turnOff para objetos de la clase Lamp
     */
    public void turnOff()
    {
     this.state = LAMP_OFF;
    }
    
    /**
     * método toString para objetos de la clase Lamp
     * @return el valor del String cadena declarado como variable local;
     */
    public String toString()
    {
     String cadena;
     if (getState() == LAMP_ON )
         cadena = "ENCENDIDA";
         else
             cadena = "APAGADA";
     return cadena;
    }
}
