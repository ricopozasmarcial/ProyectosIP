
/**
 * Write a description of class Figure here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Figure
{
  //constantes de la clase Figure
  public final static int X_LOWER_EDGE = 0;
  public final static int Y_LOWER_EDGE = 0;
  public final static int X_UPPER_EDGE = 640;
  public final static int Y_UPPER_EDGE = 320;
  public final static char LEFT = 'L';
  public final static char RIGHT = 'R';
  public final static char UP = 'U';
  public final static char DOWN = 'D';
  public final static int STEP = 10;
    
  //atributos de la clase Figure
  private String name;
  private int xPos;
  private int yPos;
  
  /**
   * constructor por defecto de objetos de la clase Figure
   */
  public Figure()
  {
   setName("Pikachu");
   setXPos(X_LOWER_EDGE);
   setYPos(Y_LOWER_EDGE);
  }
  
  /**
   * constructor con parámetros de  objetos de la clase Figure
   * @param name, un String que asigna el nombre
   * @param xPos, un entero que asigna un valor posicion en el eje x
   * @param yPos, un entero que asigna un valor posicion en el eje y
   */
  public Figure(String name, int xPos, int yPos)
  {
   this();
   setName(name);
   setXPos(xPos);
   setYPos(yPos);
  } 
  
  /**
   * metodo set para el atributo name
   * @param name, un String que asigna el nombre
   */
  private void setName(String name)
  {
   this.name = name;
  }
  
  /**
   * metodo set para el atributo xPos
   * @param xPos, un entero que asigna un valor posicion en el eje x
   */
  private void setXPos(int xPos)
  {
   this.xPos = xPos;
  }
  
  /**
   * metodo set para el atributo yPos
   * @param yPos, un entero que asigna un valor posicion en el eje y
   */
  private void setYPos(int yPos)
  {
   this.yPos = yPos;
  }
  
  /**
   * metodo get para el atributo name
   * @return el valor de name
   */
  public String getName()
  {
    return this.name;
  }
  
  /**
   * metodo get para el atributo xPos
   * @return el valor de xPos
   */
  public int getXPos()
  {
    return this.xPos;
  }
  
  /**
   * metodo get para el atributo yPos
   * @return el valor de yPos
   */
  public int getYPos()
  {
   return this.yPos;
  }
  
  /**
   * metodo move de la clase Figure
   * @param position que establece un valor nuevo a las posiciones de los ejes X e Y
   */
  public void move(char position)
  {
   if(position == Figure.LEFT) 
      {
       this.xPos = getXPos() - STEP;
       if(this.xPos < X_LOWER_EDGE || this.xPos > X_UPPER_EDGE)
          this.xPos = getXPos() + STEP; 
      }
   if(position == Figure.RIGHT) 
      {
       this.xPos = getXPos() + STEP;
       if(this.xPos < X_LOWER_EDGE || this.xPos > X_UPPER_EDGE)
          this.xPos = getXPos() - STEP; 
      }
   if(position == Figure.UP) 
      {
       this.yPos = getYPos() + STEP;
       if(this.yPos < Y_LOWER_EDGE || this.yPos > Y_UPPER_EDGE)
          this.yPos = getYPos() - STEP;
      }
   if(position == Figure.DOWN) 
      {
       this.yPos = getYPos() - STEP;
       if(this.yPos < Y_LOWER_EDGE || this.yPos > Y_UPPER_EDGE)
          this.yPos = getYPos() + STEP;
      }
   }
   
   /**
    * metodo toString de la clase Figure
    * @retrun el valor de cadena
    */
   public String toString()
   {
    String cadena = getName() + " " +  "(" + getXPos() + "," + getYPos() + ")";
    return cadena;
   }
}

