

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class NunchukTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class NunchukTest
{
    /**
     * Default constructor for test class NunchukTest
     */
    public NunchukTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo de prueba de advance
     */
    @Test
    public void testAdvance()
    {
     //caso1 se intenta dar un numero de pasos fuera del borde a la izquierda
     Nunchuk nunchuk1 = new Nunchuk();
     nunchuk1.advance(Nunchuk.LEFT);
     assertEquals(0, nunchuk1.getPersonaje().getXPos());
     
     //caso 2 se intenta dar un numero de pasos fuera del borde a la derecha
     nunchuk1 = new Nunchuk(new Figure("pikachu", 640, 0), null);
     nunchuk1.advance(Nunchuk.RIGHT);
     assertEquals(640, nunchuk1.getPersonaje().getXPos());
     
     //caso 3 se intenta dar un numero de pasos fuera del borde superior
     nunchuk1 = new Nunchuk(new Figure("pikachu", 0, 320), null);
     nunchuk1.advance(Nunchuk.UP);
     assertEquals(320, nunchuk1.getPersonaje().getYPos());
     
     //caso 4 se intenta dar un numero de pasos fuera de borde infierior
     nunchuk1 = new Nunchuk(new Figure("pikachu", 0, 0), null);
     nunchuk1.advance(Nunchuk.DOWN);
     assertEquals(0, nunchuk1.getPersonaje().getYPos());
     
     //caso 5 se da un paso correcto
     
     nunchuk1 = new Nunchuk(new Figure("pikachu", 200, 200), null);
     nunchuk1.advance(Nunchuk.UP);
     assertEquals(210, nunchuk1.getPersonaje().getYPos());
     nunchuk1.advance(Nunchuk.RIGHT);
     assertEquals(210, nunchuk1.getPersonaje().getXPos());
     
    }
    
    /**
     * metodo de prueba para midleAdvance
     */
    @Test
    public void testMidleAdvance()
    {
     //caso1 se intenta dar un numero de pasos fuera del borde a la izquierda
     Nunchuk nunchuk1 = new Nunchuk();
     nunchuk1.midleAdvance(Nunchuk.LEFT);
     assertEquals(0, nunchuk1.getPersonaje().getXPos());
     
     //caso 2 se intenta dar un numero de pasos fuera del borde a la derecha
     nunchuk1 = new Nunchuk(new Figure("pikachu", 640, 0), null);
     nunchuk1.midleAdvance(Nunchuk.RIGHT);
     assertEquals(640, nunchuk1.getPersonaje().getXPos());
     
     //caso 3 se intenta dar un numero de pasos fuera del borde superior
     nunchuk1 = new Nunchuk(new Figure("pikachu", 0, 320), null);
     nunchuk1.midleAdvance(Nunchuk.UP);
     assertEquals(320, nunchuk1.getPersonaje().getYPos());
     
     //caso 4 se intenta dar un numero de pasos fuera de borde infierior
     nunchuk1 = new Nunchuk(new Figure("pikachu", 0, 0), null);
     nunchuk1.midleAdvance(Nunchuk.DOWN);
     assertEquals(0, nunchuk1.getPersonaje().getYPos());
     
     //caso 5 se da un paso correcto
     
     nunchuk1 = new Nunchuk(new Figure("pikachu", 200, 200), null);
     nunchuk1.midleAdvance(Nunchuk.UP);
     assertEquals(220, nunchuk1.getPersonaje().getYPos());
     nunchuk1.midleAdvance(Nunchuk.RIGHT);
     assertEquals(220, nunchuk1.getPersonaje().getXPos());
    }
    
    /**
     * metodo de prueba para  muchAdvance
     */
    @Test
    public void testMuchAdvance()
    {
     //caso1 se intenta dar un numero de pasos fuera del borde a la izquierda
     Nunchuk nunchuk1 = new Nunchuk();
     nunchuk1.muchAdvance(Nunchuk.LEFT);
     assertEquals(0, nunchuk1.getPersonaje().getXPos());
     
     //caso 2 se intenta dar un numero de pasos fuera del borde a la derecha
     nunchuk1 = new Nunchuk(new Figure("pikachu", 640, 0), null);
     nunchuk1.muchAdvance(Nunchuk.RIGHT);
     assertEquals(640, nunchuk1.getPersonaje().getXPos());
     
     //caso 3 se intenta dar un numero de pasos fuera del borde superior
     nunchuk1 = new Nunchuk(new Figure("pikachu", 0, 320), null);
     nunchuk1.muchAdvance(Nunchuk.UP);
     assertEquals(320, nunchuk1.getPersonaje().getYPos());
     
     //caso 4 se intenta dar un numero de pasos fuera de borde infierior
     nunchuk1 = new Nunchuk(new Figure("pikachu", 0, 0), null);
     nunchuk1.muchAdvance(Nunchuk.DOWN);
     assertEquals(0, nunchuk1.getPersonaje().getYPos());
     
     //caso 5 se da un paso correcto
     
     nunchuk1 = new Nunchuk(new Figure("pikachu", 200, 200), null);
     nunchuk1.muchAdvance(Nunchuk.UP);
     assertEquals(250, nunchuk1.getPersonaje().getYPos());
     nunchuk1.muchAdvance(Nunchuk.RIGHT);
     assertEquals(250, nunchuk1.getPersonaje().getXPos());
    }
    
    /**
     * metodo de prueba de shootWeapon() 
     */
    @Test
    public void testShootWeapon()
    {
      //caso en que el booleano sea true
      Nunchuk nunchuk1 = new Nunchuk(null, new Weapon("Pistola", 7));
      nunchuk1.shootWeapon(true);
      assertEquals(2, nunchuk1.getArma().getAmmunition());
      
      //caso en que el booleano sea false
      nunchuk1 = new Nunchuk(null, new Weapon("Pistola", 7));
      nunchuk1.shootWeapon(false);
      assertEquals(6, nunchuk1.getArma().getAmmunition());
    }
    
    /**
     * metodo de prueba de shootForward()
     */
    @Test
    public void testShootForward()
    {
     //caso en que se mueva a la derecha y sea un movimiento valido
     Nunchuk nunchuk1 = new Nunchuk(new Figure(), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.RIGHT);
     assertEquals(10, nunchuk1.getPersonaje().getXPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
     
     //caso en que se mueva a la derecha y sea un movimiento invalido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 640, 320), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.RIGHT);
     assertEquals(640, nunchuk1.getPersonaje().getXPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
     
     //caso en que se mueva a la izquierda ysea un movimiento valido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 640, 320), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.LEFT);
     assertEquals(630, nunchuk1.getPersonaje().getXPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
    
     //caso en que se mueva a la izquierda ysea un movimiento invalido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 0, 320), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.LEFT);
     assertEquals(0, nunchuk1.getPersonaje().getXPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
     
     //caso en que se mueva arriba y sea un movimiento valido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 640, 0), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.UP);
     assertEquals(10, nunchuk1.getPersonaje().getYPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
     
     //caso en que se mueva arriba y sea un movimiento invalido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 640, 320), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.UP);
     assertEquals(320, nunchuk1.getPersonaje().getYPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
     
     //caso en que se mueva abajo y sea un movimiento valido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 640, 320), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.DOWN);
     assertEquals(310, nunchuk1.getPersonaje().getYPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
     
     //caso en que se mueva abajo y sea un movimiento ivalido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 640, 0), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.DOWN);
     assertEquals(0, nunchuk1.getPersonaje().getYPos());
     assertEquals(6, nunchuk1.getArma().getAmmunition());
     
     //caso en que sea un movimiento valido
     nunchuk1 = new Nunchuk(new Figure("Pikcahu", 640, 320), new Weapon("Pistola", 7));
     nunchuk1.shootForward(Nunchuk.DOWN);
     nunchuk1.shootForward(Nunchuk.LEFT);
     assertEquals(630, nunchuk1.getPersonaje().getXPos());
     assertEquals(310, nunchuk1.getPersonaje().getYPos());
     assertEquals(5, nunchuk1.getArma().getAmmunition());
    }
    
}
