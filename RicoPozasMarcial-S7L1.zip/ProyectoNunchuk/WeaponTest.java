

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class WeaponTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class WeaponTest
{
    /**
     * Default constructor for test class WeaponTest
     */
    public WeaponTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo de prueba para shoot()
     */
    @Test
    public void testShoot()
    {
     //caso en el que haya municion > 0
     Weapon weapon1 = new Weapon();
     weapon1.shoot();
     assertEquals(6, weapon1.getAmmunition());
     
     //caso en que el haya municion = 0
     weapon1 = new Weapon("pistola", 0);
     weapon1.shoot();
     assertEquals(0, weapon1.getAmmunition());
     
     //caso en que la municion < 0 (la municion se establece al valor del constructor por defecto
     weapon1 = new Weapon("pistola", -60);
     weapon1.shoot();
     assertEquals(6, weapon1.getAmmunition());
    }
    
    /**
     * metodo de prueba para toString()
     */
    @Test
    public void testToString()
    {
     //caso para los valores por defecto y para cualquier valor
     Weapon weapon1 = new Weapon();
     weapon1.toString();
     assertEquals(weapon1.getName() + " " + "(" + weapon1.getAmmunition() + ")", weapon1.toString());
    }
}
