
/**
 * Write a description of class Nunchuk here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nunchuk
{
    //constantes de la clase Nunchuk
    public final static Figure DEF_FIGURE = new Figure();
    public final static Weapon DEF_WEAPON = new Weapon();
    public final static String LEFT = "left";
    public final static String RIGHT = "right";
    public final static String UP = "up";
    public final static String DOWN = "down";
    
    //atributos de la clase Nunchuk
    private Figure personaje;
    private Weapon arma;
    
    /**
     * constructor por defecto de objetos de la clase Nunchuk
     */
    public Nunchuk()
    {
     setPersonaje(DEF_FIGURE);
     setArma(DEF_WEAPON);
    }
    
    /**
     * constructor con parametros de objetos de la clase Nunchuk
     * @param personaje, establece un objeto Figure
     * @param arma, establece un objeto Weapon
     */
    public Nunchuk(Figure personaje, Weapon arma)
    {
     this();
     setPersonaje(personaje);
     setArma(arma);
    }
    
    /**
     * metodo set para el atributo figure1
     * @param figure1 que establece un objeto de la clase Figure
     */
    private void setPersonaje (Figure personaje)
    {
     if (personaje != null)
         this.personaje = personaje;
    }
    
    /**
     * metodo set para el atributo weapon1
     * @param weapon1 que establece un objeto de la clase Weapon 
     */
    private void setArma (Weapon arma)
    {
     if (arma != null)
         this.arma = arma;
    }
    
    /**
     * metodo get para el atributo personaje
     * @return el valor de personaje
     */
    public Figure getPersonaje()
    {
     return this.personaje;
    }
    
    /**
     * metodo get para el atributo arma
     * @return el valor de arma
     */
    public Weapon getArma()
    {
     return this.arma;
    }
    
    /**
     * metodo advance de la clase nunchuk
     * @param movement, un string que indica la direccion del movimiento
     */
    public void advance(String movement) 
    {
     if(movement == LEFT)
        personaje.move(Figure.LEFT);
     if(movement == RIGHT)
        personaje.move(Figure.RIGHT);
     if(movement == UP)
        personaje.move(Figure.UP);
     if(movement == DOWN)
        personaje.move(Figure.DOWN);
    }
    
    /**
     * metodo midleAdvance de la clase Nunchuk
     * @param movement, un string que indica el movimiento
     */
    public void midleAdvance(String movement)
    {
     if(movement == LEFT)
        {
        personaje.move(Figure.LEFT);
        personaje.move(Figure.LEFT);
        }
     if(movement == RIGHT)
        {
        personaje.move(Figure.RIGHT);
        personaje.move(Figure.RIGHT);
        }
     if(movement == UP)
        { 
         personaje.move(Figure.UP);
         personaje.move(Figure.UP);   
        }
     if(movement == DOWN)
       { 
        personaje.move(Figure.DOWN);
        personaje.move(Figure.DOWN);
        }
    }
    
    /**
     * metodo muchAdvance de la clase Nunchuk
     * @param movement, un string que indica el movimiento
     */
    public void muchAdvance(String movement)
    {
     if(movement == LEFT)
        {
        personaje.move(Figure.LEFT);
        personaje.move(Figure.LEFT);
        personaje.move(Figure.LEFT);
        personaje.move(Figure.LEFT);
        personaje.move(Figure.LEFT);
        }
     if(movement == RIGHT)
        {
        personaje.move(Figure.RIGHT);
        personaje.move(Figure.RIGHT);
        personaje.move(Figure.RIGHT);
        personaje.move(Figure.RIGHT);
        personaje.move(Figure.RIGHT);
        }
     if(movement == UP)
        { 
        personaje.move(Figure.UP);
        personaje.move(Figure.UP);
        personaje.move(Figure.UP);
        personaje.move(Figure.UP);
        personaje.move(Figure.UP);   
        }
     if(movement == DOWN)
       { 
        personaje.move(Figure.DOWN);
        personaje.move(Figure.DOWN);
        personaje.move(Figure.DOWN);
        personaje.move(Figure.DOWN);
        personaje.move(Figure.DOWN);
        }    
    }
    
    /**
     * metodo shootWeapon de la clase Nunchuk
     * @param tipoDeDisparo, un booleano que indica el tipo de disparo que realiza el arma
     */
    public void shootWeapon(boolean tipoDeDisparo)
    {
     if(tipoDeDisparo == true)
        {
         getArma().shoot();
         getArma().shoot();
         getArma().shoot();
         getArma().shoot();
         getArma().shoot();
        }
        else
            getArma().shoot();
    }
    
    /**
     * metodo shootForward de la clase Nunchuk
     * @param movement, un string que indica la direccion del movimiento y disparo
     */
    public void shootForward(String movement)
    {
     if(movement == LEFT)
        {
         getPersonaje().move(Figure.LEFT);
         getArma().shoot();
        }
     if(movement == RIGHT)
        {
         personaje.move(Figure.RIGHT);
         getArma().shoot();
        }
     if(movement == UP)
        {
         personaje.move(Figure.UP);
         getArma().shoot();
        }
     if(movement == DOWN)
        {
         personaje.move(Figure.DOWN);
         getArma().shoot();
        }
    }
    
    /**
     * metodo print de la clase nunchuk
     */
    public void print()
    {
     System.out.println(getPersonaje().toString());
     System.out.println(getArma().toString());     
    }
    }

