
/**
 * Write a description of class Weapon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Weapon
{
   //constantes de la clase Weapon
   public final static int MIN_AMMO = 0;
   public final static int DEF_AMMO = 7;
   
   //atributos de la clase Weapon
   private String name;
   private int ammunition;
   
   /**
    * constructor por defecto de objetos de la clase Weapon
    */
   public Weapon()
   {
    setName("Pistola");
    setAmmunition(DEF_AMMO);
   }
   
   /**
    * constuctor con parámetros de objetos de la clase Weapon
    * @param name, un string que define el nombre del arma
    * @param amunnition, un entero que define la municion del arma
    */
   public Weapon (String name, int ammunition)
   {
    this();
    setName(name); 
    setAmmunition(ammunition);
   }
   
   /**
    * metodo set para el atributo name
    * @param name, un string que da valor al nombre del arma
    */
   private void setName(String name)
   {
    this.name = name;
   }
   
   /**
    * metodo set para el atributo amunnition
    * @param amunnition, un entero que define la municion del arma
    */
   private void setAmmunition(int ammunition)
   {
    if (ammunition >= MIN_AMMO)
        this.ammunition = ammunition;
        else
            this.ammunition = this.ammunition;
   }
   
   /**
    * metodo get del atributo name
    * @return el valor de name
    */
   public String getName()
   {
    return this.name;
   }
   
   /**
    * metodo get del atributo ammunition
    * @return el valor de ammunition
    */
   public int getAmmunition()
   {
    return this.ammunition;
   }
   
   public void shoot()
   {
    if (getAmmunition() > 0)
       {
        System.out.println("BANG");
        this.ammunition = getAmmunition() -1;
        }
        else
            this.ammunition = this.ammunition;
   } 
   
   /**
    * metodo toString de la clase Weapon
    * @return el valor de la cadena
    */
   public String toString()
   {
    String cadena = (getName() + " " + "(" + getAmmunition() + ")");
    return cadena;    
   }
}
