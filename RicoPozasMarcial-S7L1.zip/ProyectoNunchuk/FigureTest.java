

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class FigureTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class FigureTest
{
    /**
     * Default constructor for test class FigureTest
     */
    public FigureTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo de prueba de move()
     */
    @Test
    public void testMove()
    {
     //caso en que el valor de x intente ser menor que el borde
     Figure figure1 = new Figure();
     figure1.move(Figure.LEFT);
     assertEquals(0, figure1.getXPos());
     
     //caso en que el valor de x intente ser mayor que el borde
     figure1 = new Figure("pikachu", Figure.X_UPPER_EDGE, Figure.Y_LOWER_EDGE);
     figure1.move(Figure.RIGHT);
     assertEquals(Figure.X_UPPER_EDGE, figure1.getXPos());
     
     //caso en que el valor de y intente ser menor que el borde
     figure1 = new Figure();
     figure1.move(Figure.DOWN);
     assertEquals(0, figure1.getYPos());
     
     //caso en que el valor de y intente ser mayor que el borde
     figure1 = new Figure("pikachu", Figure.X_LOWER_EDGE, Figure.Y_UPPER_EDGE);
     figure1.move(Figure.UP);
     assertEquals(Figure.Y_UPPER_EDGE, figure1.getYPos());
     
     //caso en que el valor de x e y sean validos ambos
     figure1 = new Figure("pikachu", Figure.X_UPPER_EDGE, Figure.Y_UPPER_EDGE);
     figure1.move(Figure.LEFT);
     assertEquals(Figure.X_UPPER_EDGE - Figure.STEP , figure1.getXPos());
     figure1.move(Figure.DOWN);
     assertEquals(Figure.Y_UPPER_EDGE - Figure.STEP , figure1.getYPos());
    }
    
    /**
     * metodo de prueba para toString()
     */
    @Test
    public void testToSTring()
    {
     //caso para los valores por defecto y pata cualquier valor
     Figure figure1 = new Figure();
     assertEquals(figure1.getName() + " " +  "(" + figure1.getXPos() + "," + figure1.getYPos() + ")", figure1.toString());
    }
}
