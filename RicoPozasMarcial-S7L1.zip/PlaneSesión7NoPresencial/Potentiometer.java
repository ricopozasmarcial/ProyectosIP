
/**
 * Clase Potentiometer de la sesión 6
 * 
 * @author MARCIAL RICO POZAS 
 * @version 31/10/2017
 */
public class Potentiometer
{
    //constantes de la clase Potentiometer
    public final static int MIN_POT = 0;
    public final static int MAX_POT = 10;
    
    //atributos de la clase potentiometer
    private int position;
    /**
     * constructor por defecto de la clase Potentiometer
     */
    public Potentiometer()
    {
     setPosition(MIN_POT);
    }
    
    /**
     * metodo set del atributo position
     * @param position, un entero que establece el valor del potenciometro
     */
    private void setPosition(int position)
    {
     this.position = position;
    }
    
    /**
     * metodo get del atributo switchPosition
     * @return el valor de position
     */    
    public int getPosition()
    {
     return position;
    }
    
    /**
     * metodo movePosition de la clase Potentiometer, cambia el valor del atributo position
     * @param newPosition, un entero que modifica el valor del potenciometro
     */
    public void movePosition(int newPosition)
    {
     if(newPosition >= MIN_POT && newPosition <= MAX_POT)
        this.position = newPosition;
        else
            this.position = this.position;
    }
    
    /**
     * metodo toString de la clase Potentiometer
     * @return un String con el estado del potenciometro
     */
    public String toString()
    {
     String cadena = "" + getPosition();
     return cadena;
    }
}
