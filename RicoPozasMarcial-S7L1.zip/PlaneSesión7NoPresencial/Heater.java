
/**
 * Clase Heater de la sesión 6
 * 
 * @author MARCIAL RICO POZAS
 * @version 30/10/2017
 */
public class Heater
{
   //constantes de la clase Heater
   public final static double MIN_TEMP = 10.0;
   public final static double MAX_TEMP = 27.0;
   
   //atributos de la clase Heater
   private double temperature;
   
   /**
    * constructor por defecto de objetos de la clase Heater
    */
   public Heater()
   {
    setTemperature(MIN_TEMP);
   }
   
   /**
    * metodo set del atributo temperature
    * @param temperature, un double que establece el valor de la temperatura
    */
   private void setTemperature(double temperature)
   {
    if(temperature >= MIN_TEMP && temperature <= MAX_TEMP)
       this.temperature = temperature;
       else
           this.temperature = this.temperature;
   }
   
   /**
    * metodo get del atributo temperature
    * @return el valor de temperature
    */
   public double getTemperature()
   {
    return temperature;
   }
   
   /**
    * metodo changeTemperature de la clase Heater
    * @param newTemperature, un double que establece un nuevo valor a la temperatura, de ser invalido se dejaria el valor anterior
    */
   public void changeTemperature(double newTemperature)
   {
    if(newTemperature >= MIN_TEMP && newTemperature <= MAX_TEMP)
       this.temperature = newTemperature;
       else
           this.temperature = this.temperature;
   }
   
   /**
    * metodo toString de la clase Heater
    * @return una cadena con el estado de Heater
    */
   public String toString()
   {
    String cadena = getTemperature() + "ºC";
    return cadena;
   }
}
