
/**
 * Ejercicio Laboratorio Introducción a la programación.
 * 
 * @author (Marcial Rico Pozas) 
 * @version (19/09/2017)
 */
public class Person
{
    // instance variables - replace the example below with your own
    private int age;
    private String name;
    private String surname;
    private boolean gender;
    
    public Person()
    {
        age = 18;
        name = "Marcial";
        surname = "Rico";
        gender = true;
    }
    
    
        public void setAge(int newAge)
    {
        age = newAge;
    }

    public int getAge ()
    {
        return age;
    }
    
    public void setName (String newName)
    { 
        name = newName;
    }
    
    public String getName ()
    {
        return name;
    }
        
    public void setSurname (String newSurname)
    {  
        surname = newSurname;
    }
    
    public String getSurname ()
    {
        return surname;
    }
    
    public void setGender (boolean newGender)
    {
        gender = newGender;
    }
    
    public boolean getGender ()
    {
        return gender;
    }
    
   
    }    