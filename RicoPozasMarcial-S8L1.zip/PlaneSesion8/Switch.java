
/**
 * Clase Switch de la sesión 6
 * 
 * @author MARCIAL RICO POZAS 
 * @version 30/10/2017
 */
public class Switch
{
    //constantes de la clase Switch
    public final static boolean ON = true;
    public final static boolean OFF = false;

    // atributos de la clase Switch
    private boolean switchPosition;

    /**
     * constructor por defecto de la clase Switch
     */
    public Switch()
    {
        setSwitchPosition(OFF);
    }

    /**
     * constructor con parametro de la clase Switch
     * @param position, un booleano que establece la posicion del boton
     */
    public Switch(boolean position)
    {
        this();
        setSwitchPosition(position);
    }

    /**
     * metodo set del atibuto switchPosition
     */
    private void setSwitchPosition (boolean switchPosition)
    {
        this.switchPosition = switchPosition;
    }

    /**
     * metodo get del atributo switchPosition
     * @return el valor de switchPosition
     */
    public boolean getSwitchPosition()
    {
        return this.switchPosition;
    }

    /**
     * metodo press de la clase Switch
     * cambia el estado del interruptor de ON a OFF y viceversa
     */
    public void press()
    {
        if(getSwitchPosition()== OFF)
            this.switchPosition = ON;
        else if(getSwitchPosition() == ON)
            this.switchPosition = OFF; 
    }

    /**
     * metodo toString que devuelve una cadena con el estado del interruptor
     * @return el valor de la cadena
     */
    public String toString()
    {
        String cadena;
        if (getSwitchPosition() == ON )
            cadena = "ON";
        else
            cadena = "OFF";
        return cadena;    
    }
}
