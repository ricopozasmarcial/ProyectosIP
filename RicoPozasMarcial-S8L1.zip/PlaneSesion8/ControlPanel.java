
/**
 * clase ControlPanel de la tarea no presencial de la sesión 6
 * 
 * @author MARCIAL RICO POZAS 
 * @version 29/10/2017
 */
public class ControlPanel
{
    //atributos de la clase ControlPanel
    private Lamp lamp1;
    private Switch switch1;
    private Heater heater1;
    private Potentiometer potentiometer1;

    /**
     * consturctor por defecto de la clase ControlPanel
     */
    public ControlPanel()
    {
        setLamp1(new Lamp());
        setSwitch1(new Switch());
        setHeater1(new Heater());
        setPotentiometer1(new Potentiometer());

    }

    /**
     * constructor con parámetros de la clase ControlPanel
     * @param lamp1, de tipo Lamp que crea un objeto Lamp nuevo
     * @param switch1 de tipo Switch que crea un objeto Switch nuevo
     * @param heater1 de tipo Heater que crea un objeto Heater nuevo 
     * @param potentiometer1  de tipo Potentiometer que crea un objeto Potentiometer nuevo
     */
    public ControlPanel(Lamp lamp1, Switch switch1, Heater heater1, Potentiometer potentiometer1 )
    {
        setLamp1(lamp1);
        setSwitch1(switch1);
        setHeater1(heater1);
        setPotentiometer1(potentiometer1);
    }

    /**
     * metodo set del atributo lamp1
     * @param lamp1, de tipo Lamp que crea un objeto Lamp nuevo
     */
    private void setLamp1(Lamp lamp1)
    {
        if (lamp1 != null)
            this.lamp1 = lamp1;
    }

    /**
     * metodo set del atributo switch1
     * switch1 de tipo Switch que crea un objeto Switch nuevo
     */
    private void setSwitch1(Switch switch1)
    {
        if (switch1 != null)
            this.switch1 = switch1;
    }

    /**
     * metodo set del atributo heater1
     * @param heater1 de tipo Heater que crea un objeto Heater nuevo 
     */
    private void setHeater1(Heater heater1)
    {
        if (heater1 != null)
            this.heater1 = heater1;
    }

    /**
     * metodo set del atributo potentiometer1
     * @param potentiometer1  de tipo Potentiometer que crea un objeto Potentiometer nuevo
     */
    private void setPotentiometer1(Potentiometer potentiometer1)
    {
        if (potentiometer1 != null)
            this.potentiometer1 = potentiometer1;
    }

    /**
     * metodo set del atributo lamp1
     * @return el valor de lamp1
     */
    public Lamp getLamp1()
    {
        return this.lamp1;
    }

    /**
     * metodo set del atributo switch1
     * @return el valor de switch1
     */
    public Switch getSwitch1()
    {
        return this.switch1;
    }

    /**
     * metodo set del atributo heater1
     * @return el valor de heater1
     */
    public Heater getHeater1()
    {
        return this.heater1;
    }

    /**
     * metodo set del atributo potentiometer1
     * @return el valor de potentiometer1
     */
    public Potentiometer getPotentiometer1()
    {
        return this.potentiometer1;
    }

    /**
     * metodo print de la clase ControlPanel
     */
    public void print()
    {
        System.out.println("=========== Estado del PANEL ===========");
        System.out.println("Interruptor: " + getSwitch1().toString() );
        System.out.println("Bombilla: " + getLamp1().toString() ); 
        System.out.println("Potenciómetro: " + getPotentiometer1().toString());
        System.out.println("Radiador: " + getHeater1().toString());
    }

    /**
     *  metodo press de la clase ControlPanel, cambia el estado del interruptor y en consecuencia el de la lampara
     */
    public void press()
    {
        getSwitch1().press();
        if(getSwitch1().getSwitchPosition() == Switch.ON)
            getLamp1().turnOn();
        else
            getLamp1().turnOff();
    }

    /**
     * metodo movePotentiometer de la clase ControlPanel, cambia el valor del potenciometro y en consecuencia el de la temperatura
     * @param position, un entero que asigna un nuevo valor del potenciometro
     */
    public void movePotentiometer(int position)
    {
        getPotentiometer1().movePosition(position);
        if(position == Potentiometer.MAX_POT)
            getHeater1().changeTemperature(Heater.MAX_TEMP); 
        else if(position == Potentiometer.MIN_POT)
            getHeater1().changeTemperature(Heater.MIN_TEMP); 
    }
}
