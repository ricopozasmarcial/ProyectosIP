
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class HeaterTest.
 *
 * @author  MARCIAL RICO POZAS
 * @version 30/10/2017
 */
public class HeaterTest
{
    /**
     * Default constructor for test class HeaterTest
     */
    public HeaterTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * metodo test para changeTemperature()
     */
    @Test
    public void testChangeTemperature()
    {
        //para el valor mínimo de la temperatura
        Heater heater1 = new Heater();
        heater1.changeTemperature(Heater.MIN_TEMP);
        assertEquals(Heater.MIN_TEMP,heater1.getTemperature(),0.1);

        //para el valor máximo de la temperatura
        heater1 = new Heater();
        heater1.changeTemperature(Heater.MAX_TEMP);
        assertEquals(Heater.MAX_TEMP,heater1.getTemperature(),0.1);

        //para un valor intermedio
        heater1 = new Heater();
        heater1.changeTemperature(20.0);
        assertEquals(20.0,heater1.getTemperature(),0.1);

        //para un valor invalido
        heater1 = new Heater();
        heater1.changeTemperature(-96);
        assertEquals(heater1.getTemperature(),heater1.getTemperature(),0.1);
    }

    /**
     * metodo test para toString()
     */
    @Test
    public void testToString()
    {
        //para el valor minimo de la temperatura
        Heater heater1 = new Heater();
        heater1.changeTemperature(Heater.MIN_TEMP);
        assertEquals(Heater.MIN_TEMP,heater1.getTemperature(),0.1);
        assertEquals(heater1.getTemperature() + "ºC",heater1.toString());

        //para el valor maximo de la temperatura
        heater1 = new Heater();
        heater1.changeTemperature(Heater.MAX_TEMP);
        assertEquals(Heater.MAX_TEMP,heater1.getTemperature(),0.1);
        assertEquals(heater1.getTemperature() + "ºC",heater1.toString());
    }
}
