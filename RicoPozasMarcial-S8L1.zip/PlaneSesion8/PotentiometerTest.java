
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class PotentiometerTest.
 *
 * @author  MARCIAL RICO POZAS
 * @version 30/10/2017
 */
public class PotentiometerTest
{
    /**
     * Default constructor for test class PotentiometerTest
     */
    public PotentiometerTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * metodo test para movePosition()
     */
    @Test
    public void testMovePosition()
    {
        //se mueve a la posición mínima
        Potentiometer potentiometer1 = new Potentiometer();
        potentiometer1.movePosition(0);
        assertEquals(0,potentiometer1.getPosition());

        //se mueve a la posición máxima
        potentiometer1 = new Potentiometer();
        potentiometer1.movePosition(10);
        assertEquals(10,potentiometer1.getPosition());

        //se mueve a una posición válida
        potentiometer1 = new Potentiometer();
        potentiometer1.movePosition(5);
        assertEquals(5,potentiometer1.getPosition());

        //se mueve a una posición inválida
        potentiometer1 = new Potentiometer();
        potentiometer1.movePosition(15);
        assertEquals(potentiometer1.getPosition(),potentiometer1.getPosition());
    }

    /**
     * metodo test para toString()
     */
    @Test
    public void testToString()
    {
        //para una posicion mínima
        Potentiometer potentiometer1 = new Potentiometer();
        assertEquals("" + 0, potentiometer1.toString());

        //para una posición máxima
        potentiometer1 = new Potentiometer();
        potentiometer1.movePosition(10);
        assertEquals("" + 10, potentiometer1.toString());

        //para una posición invalida
        potentiometer1 = new Potentiometer();
        potentiometer1.movePosition(20);
        assertEquals("" + potentiometer1.getPosition(), potentiometer1.toString());

    }
}
