

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Clase de prueba para la Clase Bus
 *
 * @author  (MARCIAL RICO POZAS)
 * @version (12/10/2017)
 */
public class BusTest
{
    /**
     * Default constructor for test class BusTest
     */
    public BusTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo de prueba para getOn()
     */
    @Test
    public void testGetOn()
    {
     //hay conductor y hay asientos disponibles
     Bus bus1 = new Bus(true,60);
     assertEquals(true,bus1.getOn(50));
     assertEquals(10,bus1.getAvailableSeats());
     
     // hay conductor pero no hay asientos
     bus1 = new Bus(true,60);
     assertEquals(false,bus1.getOn(90));
     assertEquals(60,bus1.getAvailableSeats());
     
     //no hay conductor y no hay asientos disponibles
     bus1 = new Bus(false,60);
     assertEquals(false,bus1.getOn(90));
     assertEquals(60,bus1.getAvailableSeats());
     
     //no hay conductor pero si hay asientos
     bus1 = new Bus(false,60);
     assertEquals(false,bus1.getOn(50));
     assertEquals(60,bus1.getAvailableSeats());
     
     //hay conductor pero un numero invalido de pasajeros
     bus1 = new Bus(true,60);
     assertEquals(false,bus1.getOn(-50));
     assertEquals(60,bus1.getAvailableSeats());
     
     //no hay conductor pero un numero invalido de pasajeros
     bus1 = new Bus(false,60);
     assertEquals(false,bus1.getOn(-50));
     assertEquals(60,bus1.getAvailableSeats());
    }
    
    /**
     * metodo de prueba para sitDriver()
     */
    @Test
    public void testSitDriver()
    {
     //el conductor  esta sentado
     Bus bus1 = new Bus(true,60);
     assertEquals(true,bus1.getDriverPresent());
     
     //el conductor no esta sentado     
     bus1 = new Bus(false,60);
     assertEquals(false,bus1.getDriverPresent());
    }
    
    /**
     * metodo de prueba para toString()
     */
    @Test
    public void testToString()
    {
     //caso en el que el conductor este y haya sitios disponibles
     Bus bus1 = new Bus(true,60);
     assertEquals("ON DUTY - 60",bus1.toString());
     //caso en el que el conductor no este y haya sitios dispon
     bus1 = new Bus(false,60);
     assertEquals("OUT OF SERVICE - 60",bus1.toString());
    }
    
}