
/**
 * Simulacro de examen. Sesión 4: clase Bus
 * 
 * @author Marcial Rico Pozas 
 * @version 10/10/2017
 */
public class Bus
{
  private final static int MIN_AVAILABLE_SEATS = 0;
  private final static int MAX_AVAILABLE_SEATS = 60;
  private final static boolean DRIVER_PRESENT = false;
  
  private boolean driverPresent;
  private int availableSeats;
  /**
   * constructor "por defecto" de objetos de la clase Bus
   */
  public Bus()
  {
   setDriverPresent(DRIVER_PRESENT);
   setAvailableSeats(MAX_AVAILABLE_SEATS);
   
  }
  /**
   * constructor de objetos de la Clase bus
   * 
   * @param driverPresent que establece si el conductor está presente o no
   * @param availableSeats que establece el número de asientos disponibles
   */
  public Bus(boolean driverPresent, int availableSeats)
  {
   this();
   setDriverPresent(driverPresent);
   setAvailableSeats(availableSeats);
  }
  /**
   * metodo set del atributo driverPresent
   * @param driverPresent que establece si el cunductor esta presente o no
   */
  public void setDriverPresent(boolean driverPresent)
  {
   this.driverPresent = driverPresent;
  }
  /**
   * @return devuelve el valor de driverPresent
   */
  public boolean getDriverPresent()
  {
    return driverPresent;
  }
  /**
   * metodo set del atributo availableSeats
   */
  public void setAvailableSeats(int availableSeats)
  {
   this.availableSeats = availableSeats;
  
  }
  /**
   * @return devuelve el valor de availableSeats
   */
  
  public int getAvailableSeats()
  {
   return availableSeats;
  }
  /**
   * metodo sitDriver que cambia driverPresent a "true"
   */
  public void sitDriver()
  {
   this.driverPresent = true;
  }
  /**
   * metodo getOn que devuelve un valor "true" o "false" en funcion 
   * del numero de asientos libres y del estado de driverPresent
   * @param passengersNumber establece un número de pasajeros
   * @return un valor true si se cumplen las condiciones del if o un false si no las cumple
   */
  public boolean getOn(int passengersNumber)
  {
    if (getAvailableSeats() >= passengersNumber && driverPresent == true && passengersNumber >= MIN_AVAILABLE_SEATS)
   { 
    availableSeats = MAX_AVAILABLE_SEATS - passengersNumber;
    return true;
   }        
       else
            return false;
   }            
  /**
   * metodo toString que devuelve una cadena
   * @return un String cadena con los valores establecidos por el if
   */
   public String toString()
  {
   String cadena;
   String data;
   if (driverPresent == true)
       data = "ON DUTY";
       else 
           data = "OUT OF SERVICE";
   cadena = data + " - " + availableSeats;        
   return cadena;
   }
    
}