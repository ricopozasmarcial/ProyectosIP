
/**
 * Clase SeatManager de la sesion 11
 * 
 * @author MARCIAL RICO POZAS
 * @version 03/12/2017
 */
public class SeatManager
{
   //atributos de la clase SeatManager
   private Person pasajero;
   private Plane avion;
   
}
