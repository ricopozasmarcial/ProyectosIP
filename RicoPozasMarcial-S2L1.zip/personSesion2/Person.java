
/**
 * Write a description of class Person here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Person
{
    // instance variables - replace the example below with your own
    public final static int MIN_AGE = 0;
    public final static int MAX_AGE = 120;
    public final static boolean GENDER_MALE = true;
    public final static boolean GENDER_FEMALE = false;
    
    private int age;
    private String name;
    private String surname;
    private boolean gender;

   /**
     * Constructor for objects of class Person
     */
    public Person()
   {
      setName("marcial");
      setAge(18);
      setSurname("rico pozas");
      setGender(true);
   }
    
    public void setAge(int newAge)
   {
     if (newAge>=0)
      age = newAge;
   }

    public int getAge ()
   {
      return age;
   }
    
    public void setName (String newName)
   {
      name= newName;
   }
    
    public String getName ()
   {
      return name;
   }
        
    public void setSurname (String newSurname)
   {
      surname = newSurname;
   }
    
    public String getSurname()
   {
     return surname;
   }
    
    public void setGender (boolean newGender)
   {
     gender = newGender;
   }
    
    public boolean getGender ()
   {
     return gender;
   }
   
    public void print()
   {
     System.out.println("mi edad es "+ getAge() + "pero el año que viene tendre" + ( getAge() +1) + "años");
     System.out.println("datos completos de persona");
     System.out.println(toString());
   }
   
    public String toString()
   {
     String data;
       
     System.out.println( "nombre =" + getName() + "apellido =" + getSurname() + "Edad =" + getAge() + "Sexo ="); 
     if (gender)
      data = data + "masculino";
     else
      data = data + "femenino";
     
     return data;
   }
}
