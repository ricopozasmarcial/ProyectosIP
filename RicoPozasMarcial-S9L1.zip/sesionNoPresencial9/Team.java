import java.util.ArrayList;

/**
 * clase Team de la sesion no presencial 9
 * 
 *  @author MARCIAL RICO POZAS
 *  @version 16/11/2017
 */

public class Team
{
    //atributos de la clase Team
    private ArrayList<Player> equipo;

    /**
     * constructor por defecto de objetos de la clase Team
     */
    public Team()
    {
        equipo = new ArrayList<Player>();
    }

    /**
     * metodo set del atributo equipo
     * @param equipo que establece el valor del array equipo
     */
    private void setEquipo( ArrayList<Player> equipo)
    {
        this.equipo = equipo;
    }

    /**
     * metodo get del atributo equipo
     */
    public ArrayList getEquipo()
    {
        return this.equipo;
    }

    /**
     * metodo addPlayer del arrayList que añade un jugador nuevo al equipo
     */
    public void addPlayer (Player jugador)
    {
        if (jugador != null)
            equipo.add(jugador);
    }

    /**
     * metodo addPlayerIndex del arrayList que añade un nuevo jugador con un numero al equipo
     * @param jugador, un Player que indica el jugador a introducir
     * @param index, un int que indica el numero que ocupa el jugador en el Array
     */
    public void addPlayerIndex(int index, Player jugador)
    {
        if(index >0 && index <equipo.size())
            if (jugador !=null)   
                equipo.add(index,jugador);           
    }

    /**
     * metodo seekPlayer del arrayList
     * @param number, que indica el numero del jugador a buscar
     */
    public Player seekPlayer(int number)
    {
        for(Player jugador: equipo)
        {       
            if (jugador.getNumber() == number)
                return jugador;
        }
        return null;
    }

    /**
     * metodo trainPlayers de la clase Team
     */
    public ArrayList<Player> trainPlayer()
    {
        ArrayList<Player> listaImpares = new ArrayList<Player>();
        //while (index<equipo.size()) {... index = index +2;
        for( Player jugador : equipo)
        {
            if (jugador.getNumber()%2 != 0)
                listaImpares.add(jugador);
        }
        return listaImpares;
    }

    /**
     * metodo removePlayer de la clase Team
     * @param number, que indica el numero del jugador a eliminar
     */
    public void  removePlayer(int number)
    {
        int index =0;
        for ( Player jugador : equipo)
        { 
            if(jugador.getNumber() == number)
                equipo.remove(index);
            index = index + 1;
        }
    }

    /**
     * metodo seePlayers de la clase Team
     */
    public void seePlayers()
    {
        int index = 0;
        while (index< equipo.size())
        {
            System.out.println(equipo.get(index).getName()+ " " + equipo.get(index).getNumber());
            index = index + 1;
        }
    }
}

