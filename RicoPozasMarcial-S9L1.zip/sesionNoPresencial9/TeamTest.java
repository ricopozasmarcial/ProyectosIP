

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.ArrayList;

/**
 * The test class TeamTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class TeamTest
{
    /**
     * Default constructor for test class TeamTest
     */
    public TeamTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /**
     * metodo de prueba de del constructor por defecto de la clase Team
     */
    @Test
    public void testTeam()
    {
     //caso en el que se crea un arrayList
     Team team1 = new Team();
     assertEquals(0, team1.getEquipo().size());
     
     
    }
    
    /**
     * metodo de prueba del metodo addPlayer
     */
    @Test
    public void testAddPlayer()
    {
     //caso en el que se añade un jugador
     Team team1 = new Team();
     team1.addPlayer(new Player());
     assertEquals(1, team1.getEquipo().size());
     
     //caso en que el que se añada otro jugador mas
     team1.addPlayer(new Player());
     assertEquals(2, team1.getEquipo().size());
     
     //caso en que añadimos null
     team1.addPlayer(null);
     assertEquals(2,team1.getEquipo().size());
    }
    
    /**
     * metodo de prueba del metodo addPlayerIndex
     */
    @Test
    public void testAddPlayerIndex()
    {
     //caso en el que se añada un jugador con un index valido
     Team team1 = new Team();
     team1.addPlayerIndex(1,new Player());
    }
    
    /**
     * metodo de prueba de seekPlayer
     */
    @Test
    public void testSeekPlayer()
    {
      //buscar entre varios elementos
      Team team1 = new Team();
      team1.addPlayer(new Player("MARCIAL", 79)); //posicion 0
      team1.addPlayer(new Player("MARCIAL", 89)); //posicion 1
      team1.addPlayer(new Player("MARCIAL", 99)); //posicion 2
      team1.seekPlayer(79);
      assertEquals(team1.getEquipo().get(0), team1.seekPlayer(79));
      
      //buscar un elemento que no existe
      team1 = new Team();
      team1.addPlayer(new Player("MARCIAL", 79)); //posicion 0
      team1.addPlayer(new Player("MARCIAL", 89)); //posicion 1
      team1.addPlayer(new Player("MARCIAL", 99)); //posicion 2
      team1.seekPlayer(9);
      assertEquals(null, team1.seekPlayer(9));
    }
}
