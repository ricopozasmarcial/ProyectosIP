
/**
 *¡clase Player de la sesion no presencial 9
 * 
 * @author MARCIAL RICO POZAS
 * @version 16/11/2017
 */
public class Player
{
    //constantes de la clase player
    public final static int DEF_NUMBER = 12;
    public final static String DEF_NAME = "Marcial";

    //atributos de la clase player
    private int number;
    private String name;

    /**
     * constructor sin parametros de la clase Player
     */
    public Player()
    {
        setName(DEF_NAME);
        setNumber(DEF_NUMBER);
    }

    /**
     * constructor con parametros de la clase Player
     * @param name, un string que establece el nombre del jugador
     * @param number, un int que establece el numero del jugador
     */
    public Player(String name, int number)
    {
        setName(name);
        setNumber(number);
    }

    /**
     * metodo set del atributo name
     * @param name, un string que establece el valor de name
     */
    private void setName(String name)
    {
        this.name = name;
    }

    /**
     * metodo set del atributo number
     * @param number, un string que establece el valor de number
     */
    private void setNumber(int number)
    {
        this.number = number;
    }

    /**
     * metodo get del atributo name
     * @return el valor de name
     */
    public String getName()
    {
        return this.name;
    }

    /**
     * metodo get del atributo number
     * @return el valor de number
     */
    public int getNumber()
    {
        return this.number;
    }
}
