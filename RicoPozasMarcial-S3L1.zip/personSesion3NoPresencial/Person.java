import java.util.Random;

/**
 * clase Person para tarea no presencial 2.
 * 
 * @author (Marcial Rico Pozas) 
 * @version (01/10/2017)
 */
public class Person
{
    public final static int MIN_AGE = 0;
    public final static int MAX_AGE = 120;
    
    public final static boolean GENDER_MALE = true;
    public final static boolean GENDER_FEMALE = false;
    
    public final static int ADULTHOOD_AGE = 18;
    public final static int RETIREMENT_AGE = 65;
    
    private int age;
    private String name;
    private String surname;
    private boolean gender;
    private int criticalAge;
   /**
     * constructor de objetos de la clase Person
     */
    public Person()
   {
     //Random r;
     
     setName("Marcial");
     //r = new Random();
     
     setAge(18);//r.nextInt(MAX_AGE) )
     setSurname("Rico Pozas");
     setGender(true);
     getCriticalAge();
   }
   
   // public Person(int age)
   //{
   //this();
   //setAge(age); 
   //}
   
   //public Person (String name)
   //{
   //this();
   //setName(name);
   //}
   
   //public Person (String name, String surname, int age, boolean gender)
   //{
   //this();
   //setName(name);
   //setSurname(surname);
   //setAge(age);
   //setGender(gender); 
   //}
   
   /**
     * metodo set para el atributo age
     */
    public void setAge(int age)
   {
     if (age>=MIN_AGE && age<MAX_AGE)
      this.age = age;
     if (age<MIN_AGE && age>=MAX_AGE)
      this.age = 000;
   }
   
   /**
    * metodo get para el altributo age
    */
    public int getAge ()
   {
      return this.age;
   }
   
   /**
    * metodo set para el atributo name
    */
    public void setName (String name)
   {
      this.name = name;
   }
   
   /**
    * metodo get para el atributo name
    */
    public String getName ()
   {
      return name;
   }
   
   /**
    * metodo set para el atributo surname
    */     
    public void setSurname (String surname)
   {
      this.surname = surname;
   }
   /**
     * metodo get para el atributo surname
     */
    public String getSurname()
   {
      return surname;
   }
   
   /**
    * metodo set para el atributo gender
    */
    public void setGender (boolean gender)
   {
      this.gender = gender;
   }
   
   /**
    * metodo get para el atributo get
    */
    public boolean getGender ()
   {
      return gender;
   }
   
   /**
    * metodo get para el atributo age
    */
    public int getCriticalAge()
   { 
    if (age <= ADULTHOOD_AGE )
     {
      criticalAge = ADULTHOOD_AGE - age;
     }
      else if (age > ADULTHOOD_AGE && age < RETIREMENT_AGE)
            {
              criticalAge = RETIREMENT_AGE - age;   
            }
             else if  (age >= RETIREMENT_AGE)
                   {
                     criticalAge = age - RETIREMENT_AGE;  
                   }    
    return criticalAge;
   }
   
   /**
    * metodo que imprime un mensaje en la pantalla de comandos
    */
    public void print()
   {
     System.out.println("Mi edad es "+ getAge() + " pero el año que viene tendre " + ( getAge() +1) + " años");
     System.out.println("Datos completos de persona");
     System.out.println(toString());
     
   }
   /**
    * METODO toString() QUE DEVUELVE UNA CADENA
    */
    public String toString()
   {
     String data = "Nombre = " + this.getName() + " Apellido = " + this.getSurname() + " Edad = " + this.getAge() + " Sexo = "; 
     if (gender == true)
      data = data + "Masculino";
     else
      data = data + "Femenino";
     return data;
   }
   
   // public void metodoDePrueba()
   //{
     //Person a,b;
     
    // a=new Person();
     //b=new Person();
    
    // b.setName ("María");
     //a.setName ("Pedro");
    
    // System.out.println(a.getName());
    // System.out.println(b.getName());
   //}
   /**
    * METODO getHashCode que devuelve una cadena
    */
   public String getHashCode()
   {
     String hashCode = (getAge() + "-" + getName() + "-" + getName().length() + "-" + getSurname() + "-" + getSurname().length()) ;
     
     return hashCode.toUpperCase();
    }
}
