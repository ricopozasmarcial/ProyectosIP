
/**
 * Write a description of class Tree here.
 * 
 * @author MARCIAL RICO POZAS 
 * @version 09/10/2017
 */
public class Tree
{
    private final static int MAX_NUMBEROFFLOWERS = 25;
    private final static int MIN_NUMBEROFFLOWERS = 0;
    private final static int MAXNUMBEROFFLOWERS = 12;
    private final static int MIN_NUMBEROFFRUITS = 0;
    private final static String DEFAULT_TYPE_OF_TREE = "Manzano";
    private final static int DEFAULT_NUMBER_OF_FLOWERS = 7;
    private final static int DEFAULT_NUMBER_OF_FRUITS = 3;
    
    private String typeOfTree;
    private int maxNumberOfFlowers;
    private int numberOfFlowers;
    private int numberOfFruits;
    /**
     * CONSTRUCTOR DE OBJETOS DE LA CLASE TREE
     */
    public Tree()
    {
      setTypeOfTree(DEFAULT_TYPE_OF_TREE);
      setMaxNumberOfFlowers(MAXNUMBEROFFLOWERS);
      setNumberOfFlowers(DEFAULT_NUMBER_OF_FLOWERS);
      setNumberOfFruits(DEFAULT_NUMBER_OF_FRUITS);
    }    
    
    /**
     * METODO SET DEL ATRIBUTO typeOfTree
     */
    public void setTypeOfTree( String newTypeOfTree )
    {
     typeOfTree = newTypeOfTree;  
    }   
    /**
     * METODO GET DEL ATRIBUTO typeOfTree
     */
    public String getTypeOfTree()
    {
     return typeOfTree;
    }    
    /**
     * METODO SET DEL ATRIBUTO maxNumberFlowers
     */
    public void setMaxNumberOfFlowers (int newMaxNumberOfFlowers )
    {
     maxNumberOfFlowers = newMaxNumberOfFlowers;
    }    
    /**
     * METODO GET DEL ATRIBUTO maxNumberOfFlowers
     */
    public int getMaxNumberOfFlowers()
    {
     return maxNumberOfFlowers;
    }    
    /**
     * METODO SET DEL ATRIBUTO numberOfFruits
     */
    public void setNumberOfFruits(int newNumberOfFruits)
    {
      numberOfFruits = newNumberOfFruits;
    }    
    /**
     * METODO GET DEL ATRIBUTO numberOfFruits
     */
    public int getNumberOfFruits()
    {
     return numberOfFruits;
    }
    /**
     * METODO SET DEL ATRIBUTO numberOfFlowers
     */
    public void setNumberOfFlowers( int newNumberOfFlowers)
    {
     if (getNumberOfFlowers() > MAX_NUMBEROFFLOWERS || getNumberOfFlowers() < MIN_NUMBEROFFLOWERS)
     {
      this.numberOfFlowers =0;
     }
     if (getNumberOfFlowers() <= MAX_NUMBEROFFLOWERS || getNumberOfFlowers() >= MIN_NUMBEROFFLOWERS)
     {
      this.numberOfFlowers = newNumberOfFlowers;
     }
     
    }
    /**
     * METODO GET DEL ATRIBUTO numberOfFlowers
     */
    public int getNumberOfFlowers()
    {
     return numberOfFlowers;
    }
    /**
     * METODO toString
     */
    public String toString()
    {
     String mensaje = ("Manzano" + " - " + getMaxNumberOfFlowers() + " - " + getNumberOfFlowers() + " - " + getNumberOfFruits());
     return mensaje;
    }
    /**
     * METODO print 
     */
    public void print()
    {
     System.out.println("Valores de las propiedades del árbol"+ toString());
    }
    /**
     * METODO water
     */
    public int water()
    {
      if (numberOfFlowers < MAXNUMBEROFFLOWERS)
      {
       setNumberOfFlowers(getNumberOfFlowers() +1);
      }
      if(numberOfFruits < MAXNUMBEROFFLOWERS)
      {
        setNumberOfFlowers(getNumberOfFlowers()-1);
        setNumberOfFruits (getNumberOfFruits() +1);
      }
      return numberOfFlowers & numberOfFruits;
      
    }
    /**
     * METODO gatherFruit()
     */
    public int gatherFruit()
    {
      setNumberOfFruits(getNumberOfFruits()-1);
      if (numberOfFruits < 0)
      {
        numberOfFruits =0;
      }
      return numberOfFruits;
    }
    /**
     * METODO harvest()
     */
    public int harvest()
    {
      return DEFAULT_NUMBER_OF_FRUITS - numberOfFruits;            
    }
    }

